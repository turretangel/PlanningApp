//
//  DetailView.swift
//  ProjectVersion1
//
//  Created by Megan Beaudoin on 3/19/23.
//

import Foundation
import SwiftUI

struct DetailView: View {
    @Environment(\.dismiss) private var dismiss
    
    
    let task: Task
    
    @ObservedObject var dataC : coreDataController
    @State var completed:Bool
    
    var body: some View {
        
        Spacer()
        Text("Current Task: \(task.name!)")
            .bold()
            .navigationTitle(task.name!)
            .navigationBarTitleDisplayMode(.inline)
        Spacer()
        HStack{
            Spacer()
            Text(task.details!).scenePadding()
            Spacer()
        }
        Spacer()
        HStack{
            Button(action: buttonAction) {
                Text("Complete?")
            }.buttonStyle(.borderedProminent)
        }
        Spacer()
        Image("Coffee1").resizable().scaledToFit()
    }
    
    private func buttonAction() {
        dataC.flipTask(name:task)
    }
        
}
