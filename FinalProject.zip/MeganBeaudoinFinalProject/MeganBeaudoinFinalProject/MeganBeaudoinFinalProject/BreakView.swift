//
//  BreakView.swift
//  ProjectVersion1
//
//  Created by Megan Beaudoin on 4/22/23.
//

import Foundation
import SwiftUI
struct activityData: Decodable{
    let activity: String
    let type: String
    let participants: Int
    let price: Double
    let link: String
    let key: String
    let accessibility: Double
}
struct BreakView: View {
    @Environment(\.dismiss) private var dismiss
    
    @ObservedObject var dataC : coreDataController
    @State var activityOut: String
    @State var typeOut: String
    @State var participantsOut: Int
    @State var priceOut:Double
    @State var linkOut:String
    @State var keyOut:String
    @State var accessabilityOut: Double
    @State var rewardNumber: Int
    @State private var showAlert = false
    var body: some View {
        
        Spacer()
        Text("You've earned: \(dataC.rewardPoints()) reward points!")
            .bold()
            .navigationTitle("Break Time!")
            .navigationBarTitleDisplayMode(.inline)
        Spacer()
        HStack{
            Spacer()
            Text("Spend a point?")
            Spacer()
            Button("Okay!") {
                if dataC.rewardPoints() > 0 {
                    getJsonData()
                    dataC.saveReward(rActivity:activityOut,rType:typeOut,rParticipants:participantsOut,rPrice:priceOut,rLink:linkOut,rKey:keyOut,rAccessability: accessabilityOut)
                    rewardNumber = (dataC.Rewards.count - 1)
                }
                else {
                    showAlert = true
                }
            }.buttonStyle(.bordered)
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("No More Reward Points"),
                          message: Text("You're out of reward points! Do more tasks to earn more!"))
                }
            Spacer()
        }
        Spacer()
        VStack{
            Text("Activity: \(activityOut)")
            Text("Type: \(typeOut)")
            Text("Participants:")
            HStack{
                ForEach(0..<participantsOut, id:\.self) { i in
                    Image(systemName:"person")
                }
            }
            Text("Price: \(Int(priceOut * 10))/10")
            ProgressView(value:priceOut)
            Text("Link: \(linkOut)")
            Text("Accessability: \(Int(accessabilityOut * 10))/10")
            ProgressView(value:accessabilityOut)
            
        }
        Spacer()
        Image("Coffee2").resizable().scaledToFit()
        //        HStack{
//            Button("Previous Unlocked Reward") {
//                if (rewardNumber > 0) {
//                    rewardNumber -= 1
//                }
//
//                activityOut = dataC.Rewards[rewardNumber].activity!
//                typeOut = dataC.Rewards[rewardNumber].type!
//                participantsOut = Int(dataC.Rewards[rewardNumber].participants)
//                priceOut = dataC.Rewards[rewardNumber].price
//                linkOut = dataC.Rewards[rewardNumber].link!
//                accessabilityOut = dataC.Rewards[rewardNumber].accessability
//
//            }.padding().buttonStyle(.borderedProminent)
//            Button("Next Unlocked Reward") {
//                if (rewardNumber < (dataC.Rewards.count - 1)) {
//                    rewardNumber += 1
//                }
//
//                activityOut = dataC.Rewards[rewardNumber].activity!
//                typeOut = dataC.Rewards[rewardNumber].type!
//                participantsOut = Int(dataC.Rewards[rewardNumber].participants)
//                priceOut = dataC.Rewards[rewardNumber].price
//                linkOut = dataC.Rewards[rewardNumber].link!
//                accessabilityOut = dataC.Rewards[rewardNumber].accessability
//
//            }.padding().buttonStyle(.borderedProminent)
//        }
        
    }
    
    func getJsonData() {
        let url = URL(string: "https://www.boredapi.com/api/activity")!
        let urlSession = URLSession.shared
        let jsonQuery = urlSession.dataTask(with: url, completionHandler: { data, response, error -> Void in
            if (error != nil) {
                print(error!.localizedDescription)
            }
            var err: NSError?

            do {
                let decodedData = try JSONDecoder().decode(activityData.self, from: data!)
                activityOut = decodedData.activity
                typeOut = decodedData.type
                participantsOut = decodedData.participants
                priceOut = decodedData.price
                linkOut = decodedData.link
                keyOut = decodedData.key
                accessabilityOut = 1 - decodedData.accessibility
                

            } catch {
                print("error: \(error)")
            }
        })
        jsonQuery.resume()
    }

        
}
