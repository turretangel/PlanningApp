//
//  MeganBeaudoinFinalProjectApp.swift
//  MeganBeaudoinFinalProject
//
//  Created by Megan Beaudoin on 4/22/23.
//

import SwiftUI

@main
struct MeganBeaudoinFinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
