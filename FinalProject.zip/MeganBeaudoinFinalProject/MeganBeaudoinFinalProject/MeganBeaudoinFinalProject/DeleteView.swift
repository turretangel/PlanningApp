//
//  DeleteView.swift
//  ProjectVersion1
//
//  Created by Megan Beaudoin on 3/19/23.
//

import Foundation
import SwiftUI

struct DeleteView: View {
    @Environment(\.dismiss) private var dismiss
    
    @ObservedObject var dataC : coreDataController
    
    var body: some View {
        VStack{
            
            ForEach(dataC.Tasks, id: \.id) { thisTask in
                Button(thisTask.name!) {
                    dataC.deleteTask(taskName:dataC.getTaskName(tName: thisTask.name!))
                }.buttonStyle(.borderedProminent)
            }
            
        }
    }
        
}
