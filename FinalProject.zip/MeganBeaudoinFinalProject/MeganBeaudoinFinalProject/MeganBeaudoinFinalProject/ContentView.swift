//
//  ContentView.swift
//  ProjectVersion1
//
//  Created by Megan Beaudoin on 3/19/23.
//

import SwiftUI
import MapKit
import CoreLocationUI

struct section:Identifiable {
    let id = UUID()
    let name: String
}

struct ContentView: View {
    
    //@ObservedObject var taskVM = TaskViewModel()
    @State var toDeleteView = false
    @Environment(\.managedObjectContext) private var viewContext
    @State var viewID = 0
    @State var taskName = String()
    @State var taskDescription = String()
    @State var taskPriority = Int()
    
    @ObservedObject var dataController: coreDataController = coreDataController()
    @State var sectionData = [
        section(name:"High Priority"),section(name:"Medium Priority"),section(name:"Low Priority"), section(name:"Completed")]
    var body: some View {
        
        NavigationView {
            VStack{
                Text("Today's Tasks:").bold().padding()
                List {
                    Section(sectionData[0].name) {
                        ForEach(dataController.getTaskPriority(tPriority:3), id: \.self) { thisTask in
                            NavigationLink(destination: DetailView(task: thisTask, dataC: dataController, completed: thisTask.complete)) {
                                HStack{
                                    VStack (alignment: .leading, spacing: 5) {
                                        Text(thisTask.name!)
                                            .fontWeight(.semibold)
                                            .minimumScaleFactor(0.5)
                                    }
                                }
                            }
                        }
                    }
                    Section(sectionData[1].name) {
                        ForEach(dataController.getTaskPriority(tPriority:2), id: \.self) { thisTask in
                            NavigationLink(destination: DetailView(task: thisTask, dataC: dataController, completed: thisTask.complete)) {
                                HStack{
                                    VStack (alignment: .leading, spacing: 5) {
                                        Text(thisTask.name!)
                                            .fontWeight(.semibold)
                                            .minimumScaleFactor(0.5)
                                    }
                                    }
                                }
                        }
                    }
                    Section(sectionData[2].name) {
                        ForEach(dataController.getTaskPriority(tPriority:1), id: \.self) { thisTask in
                            NavigationLink(destination: DetailView(task: thisTask, dataC: dataController, completed: thisTask.complete)) {
                                HStack{
                                    VStack (alignment: .leading, spacing: 5) {
                                        Text(thisTask.name!)
                                            .fontWeight(.semibold)
                                            .minimumScaleFactor(0.5)
                                    }
                                    }
                                }
                        }
                    }
                    Section(sectionData[3].name) {
                        ForEach(dataController.getTaskComplete(), id: \.self) { thisTask in
                            NavigationLink(destination: DetailView(task: thisTask, dataC: dataController, completed: thisTask.complete)) {
                                HStack{
                                    VStack (alignment: .leading, spacing: 5) {
                                        Text(thisTask.name!)
                                            .fontWeight(.semibold)
                                            .minimumScaleFactor(0.5)
                                    }
                                    }
                                }
                        }
                    }
                        
                }.navigationBarTitleDisplayMode(.inline)
                    .navigationTitle("Welcome to your coffee planner!")
                
                Spacer()
                VStack{
                    Text("Today's Progress:")
                    ProgressView(value: dataController.progress())
                    Text("\(Int(dataController.progress() * 100))% Complete!")
                }
                
                HStack{
                    
                    
                    NavigationLink(destination: AddView(dataC: dataController)) {
                        Text("Add Task")
                    }.buttonStyle(.bordered)
                    
                    NavigationLink(destination: DeleteView(dataC: dataController)) {
                        Text("Delete Task")
                    }.buttonStyle(.bordered)
                    NavigationLink(destination: TodayView(dataC: dataController)) {
                        Text("Today's Plan")
                    }.buttonStyle(.bordered)
                    NavigationLink(destination: BreakView(dataC: dataController, activityOut:"",typeOut:"",participantsOut:0,priceOut:0.0,linkOut:"",keyOut:"",accessabilityOut:0.0,rewardNumber:0)) {
                        Text("Break Time!")
                    }.buttonStyle(.bordered)
                }
            }
        }
    }
}
    



