//
//  AddView.swift
//  ProjectVersion1
//
//  Created by Megan Beaudoin on 3/19/23.
//

import Foundation
import SwiftUI

struct AddView: View {
    @Environment(\.dismiss) private var dismiss
    
    @ObservedObject var dataC : coreDataController
    @State var taskName = String()
    @State var taskDescription = String()
    @State var taskPriority = "Low"
    @State var options = ["Low", "Medium", "High"]
    var body: some View {
        
        VStack{
            Text("Add your new task here:").bold()
            Spacer()
            HStack{
                Text("Task Name:")
                TextField("Task Name", text: $taskName)
            }.scenePadding()
            HStack{
                
                Text("Task Description:")
                TextField("Task Description", text: $taskDescription)
            }.scenePadding()
            HStack{
                
                Text("Task Priority:")
                Picker("Task Priority:", selection: $taskPriority) {
                    ForEach(options, id:\.self) {item in
                        Text(item)
                    }
                }.pickerStyle(.menu)
            }.scenePadding()
            Spacer()
            Button("Submit!") {
                if taskPriority == "Low" {
                    taskPriority = "1"
                }
                else if taskPriority == "Medium" {
                    taskPriority = "2"
                }
                else if taskPriority == "High" {
                    taskPriority = "3"
                }
                dataC.saveTask(tName:taskName,tDesc:taskDescription,tPriority:Int(taskPriority)!,tComplete:false,tTime:Date())
                
                dismiss()
                
            }.buttonStyle(.borderedProminent)
            
            Spacer()
            Image("Coffee3").resizable().scaledToFit().padding()
            
        }
    }
        
}
