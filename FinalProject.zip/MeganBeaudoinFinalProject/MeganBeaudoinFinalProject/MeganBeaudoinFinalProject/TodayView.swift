//
//  TodayView.swift
//  ProjectVersion1
//
//  Created by Megan Beaudoin on 4/21/23.
//

import Foundation
import SwiftUI
import CoreLocationUI
import MapKit

struct Location: Identifiable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
    var showName:Bool
}

struct TodayView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var dataC : coreDataController
    @State var city = String()
    @State var fact1 = String()
    func geoCodeThis(addressStr:String) {
        let addressString = addressStr
        CLGeocoder().geocodeAddressString(addressString,completionHandler:{
            (placemarks,error) in
            if error != nil {
                print ("Geocode failed: \(error!.localizedDescription)")
            } else if placemarks!.count > 0 {
                let placemark = placemarks![0]
                let location = placemark.location
                let coords = location!.coordinate
                print(coords.latitude)
                print(coords.longitude)
                DispatchQueue.main.async {
                    region.center = coords
                }
            }
        })
    }
    
    
    @State private var mapSearch = false
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(
            latitude: 33.4255, longitude: -111.9400),
        span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
    )
    @State private var markers:[Location] = []
    
    @State private var searchText = ""
    
    func toggleBool(id2:UUID) {
        var loc:Int = 0
        for m in markers {
            if m.id == id2{
                print("\(m.name) is at \(loc)")
                break;
            }
            loc += 1
        }
        if loc < markers.count {
            print("\(loc) is less than \(markers.count)")
            if (markers[loc].showName) {
                markers[loc].showName = false
            }
            else {
                markers[loc].showName = true
            }
            print("bool is now \(markers[loc].showName)")
        }
        
    }

    

    var body: some View {
        VStack{
            Text("Today is:\n").bold()
            Text("\(Date(), formatter:dateFormat)")
        }.padding()
        
        Spacer()
        Text("Let's find cafes near where you're working today!")
        HStack{
            Text("Enter City You'll Be Going To:").padding()
            TextField("Enter City Name Here",text:$city)
        }
        Button("Let's Go!") {
            geoCodeThis(addressStr: city)
            
        }
        searchBar
        Map(coordinateRegion: $region,
            interactionModes: .all,
            annotationItems:markers) {
            location in
            MapAnnotation(coordinate: location.coordinate, content: {
                VStack(spacing:0){
                    
                    Text(location.name)
                        .font(.callout)
                        .padding(5)
                        .background(Color(.white))
                        .cornerRadius(5)
                        .opacity(location.showName ? 1 : 0).contentShape(RoundedRectangle(cornerRadius: 5))
                        
                        
                    Image(systemName:"pin.circle.fill")
                        .foregroundColor(.red)
                        .font(.title)
                        
                    Image(systemName:"arrowtriangle.down.fill")
                        .font(.caption)
                        .foregroundColor(.red)
                        .offset(x:0,y:-5)
                    
                }
                    .onTapGesture{
                        print("Tap!")
                        withAnimation(.easeInOut) {
                            toggleBool(id2:location.id)
                        }
                        
                        
                    }
                })
            }
        
        
    
    
    
        
    }
    
    
    
    private let dateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .none
        return formatter
    }()
var searchBar: some View {
    HStack {
        Button {
            let searchRequest = MKLocalSearch.Request()
            searchRequest.naturalLanguageQuery = searchText
            searchRequest.region = region
            mapSearch = true
            MKLocalSearch(request:searchRequest).start {
                response, error in
                guard let response = response else {
                    print("Error: \(error?.localizedDescription ?? "Unknown error!").")
                    return
                }
                region = response.boundingRegion
                markers = response.mapItems.map {
                    item in
                    Location(name: item.name ?? "",
                             coordinate: item.placemark.coordinate,
                             showName: true
                    )
                }
            }
        } label: {
            Image(systemName: "location.magnifyingglass")
                .resizable()
                .foregroundColor(.accentColor)
                .frame(width:24,height:24)
                .padding(.trailing, 12)
        }
        TextField("Search for specific cafes here!", text: $searchText)
    }.padding()
}
}
