//
//  coreDataController.swift
//  ProjectVersion1
//
//  Created by Megan Beaudoin on 4/21/23.
//

import Foundation
import CoreData
class coreDataController : ObservableObject {
    @Published var Tasks:[Task] = [Task]()
    @Published var Rewards:[Reward] = [Reward]()
    let persistentContainer:NSPersistentContainer
    
    init() {
        persistentContainer = NSPersistentContainer(name: "taskData")
        persistentContainer.loadPersistentStores { (description, error) in
            if let error = error {
                fatalError("cannot load data \(error.localizedDescription)")
            }
        }
        Tasks = getTasks()
        Rewards = getRewards()
        persistentContainer.viewContext.automaticallyMergesChangesFromParent = true
    }
    
    func saveTask(tName: String, tDesc: String, tPriority: Int, tComplete: Bool, tTime: Date) {
        let newTask = Task(context: persistentContainer.viewContext)
        newTask.name = tName
        newTask.details = tDesc
        newTask.id = UUID()
        newTask.priority = Int64(tPriority)
        newTask.complete = tComplete
        newTask.timestamp = tTime
        do {
            try persistentContainer.viewContext.save()
            Tasks = getTasks()
        } catch {
            print("failed to save \(error)")
        }
        
    }
    func deleteTask(taskName: Task) {
        persistentContainer.viewContext.delete(taskName)
        do {
            try persistentContainer.viewContext.save()
            Tasks = getTasks()
        } catch {
            print("failed to save \(error)")
        }
    }
    func getTaskName(tName:String) -> Task {
        let fetchRequest:NSFetchRequest<Task> = Task.fetchRequest()
        do {
            let x = try persistentContainer.viewContext.fetch(fetchRequest)
            for t in x {
                if t.name == tName{
                    return t
                }
            }
            objectWillChange.send()
            return x[0]
        } catch {
            return Tasks[0]
        }
    }
    func getTaskPriority(tPriority:Int) -> [Task] {
        let fetchRequest: NSFetchRequest<Task> = Task.fetchRequest()
        do {
            let x = try persistentContainer.viewContext.fetch(fetchRequest)
            var y:[Task] = []
            for t in x {
                if t.priority == Int64(tPriority) && t.complete == false{
                    y.append(t)
                }
            }
            return y
        } catch {
            return []
        }
    }
    func flipTask(name: Task) {
        let task1 = getTaskName(tName: name.name!)
        task1.complete.toggle()
        for t in Tasks {
            if t.id == task1.id {
                t.complete = task1.complete
                break
            }
        }
        do {
            try persistentContainer.viewContext.save()
            Tasks = getTasks()
        } catch {
            print("failed to save \(error)")
        }
    }
    func getTaskComplete() -> [Task] {
        let fetchRequest: NSFetchRequest<Task> = Task.fetchRequest()
        do {
            let x = try persistentContainer.viewContext.fetch(fetchRequest)
            var y:[Task] = []
            for t in x {
                if t.complete {
                    y.append(t)
                }
            }
            return y
        } catch {
            return []
        }
    }
    func progress() -> Double {
        let count = Double(Tasks.count)
        let completeCount = Double(getTaskComplete().count)
        if count == 0 {
            return 0
        }
        return Double(completeCount/count)
    }
    func getTasks() -> [Task] {
        let fetchRequest: NSFetchRequest<Task> = Task.fetchRequest()
        do {
            let x = try persistentContainer.viewContext.fetch(fetchRequest)
            return x
        } catch {
            return []
        }
    }
    func saveReward(rActivity: String, rType: String, rParticipants: Int, rPrice: Double, rLink: String, rKey: String, rAccessability: Double) {
        let newReward = Reward(context: persistentContainer.viewContext)
        newReward.activity = rActivity
        newReward.id = UUID()
        newReward.type = rType
        newReward.participants = Int64(rParticipants)
        newReward.price = rPrice
        newReward.link = rLink
        newReward.key = rKey
        newReward.accessability = rAccessability
        
        do {
            try persistentContainer.viewContext.save()
            Rewards = getRewards()
        } catch {
            print("failed to save \(error)")
        }
        
    }
    func deleteReward(rewardName: Reward) {
        persistentContainer.viewContext.delete(rewardName)
        do {
            try persistentContainer.viewContext.save()
            Tasks = getTasks()
        } catch {
            print("failed to save \(error)")
        }
    }
    func getRewards() -> [Reward] {
        let fetchRequest: NSFetchRequest<Reward> = Reward.fetchRequest()
        do {
            let x = try persistentContainer.viewContext.fetch(fetchRequest)
            return x
        } catch {
            return []
        }
    }
    func rewardPoints() -> Int {
        var sum = 0
        let completedTask = getTaskComplete()
        for i in completedTask {
            sum += Int(i.priority)
        }
        sum -= Rewards.count
        return sum
    }
}
